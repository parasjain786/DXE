package com.dxeproject.utils;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.github.tomakehurst.wiremock.WireMockServer;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClass {

	protected static String User_Dir = System.getProperty("user.dir");
	protected static final String HOST = "localhost";
	protected static final int PORT = 8080;
	protected static WireMockServer server = new WireMockServer(PORT);
	public static Properties prop;
	public static JsonPath jsonpath;
	static ExtentReports extent;
	static ExtentTest logger;
	static Logger log;
	
	

	@BeforeClass()
	public void extentReportConfig() {

		PropertyConfigurator.configure("log4j.properties");
		extent = new ExtentReports();
		String timestamp = new SimpleDateFormat("yyyyMMddHHmm").format(System.currentTimeMillis());
		ExtentSparkReporter spark = new ExtentSparkReporter(
				User_Dir + "/test-output/Extent-Reports/" + "Automation-StatusReport_" + timestamp + ".html");
		spark.config().setTheme(Theme.STANDARD);
		spark.config().setDocumentTitle("DXE-Test-Report");
		spark.config().setReportName("DXE Test Execution Report");
		spark.config().setTimeStampFormat("dd-MMM-yyyy 00:00");
		spark.config()
		.setCss(".content-footer .footer .go-right, .header .vheader .nav-right { float: left !important; }");
		extent.attachReporter(spark);
		extent.setSystemInfo("Test Category", "API Test");
		extent.setSystemInfo("Test Type", "Automation Testing");

		extent.setSystemInfo("Operating System", "Windows");
		extent.setSystemInfo("Executed by", "Paras Jain");
	}

	public String getAPISucessRespServer() {
		RestAssured.baseURI = prop.getProperty("APIBaseUrI");
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET, "?Order=" + prop.getProperty("Orderid"));
		String responseBody = response.getBody().asString();
		int statusCode = response.getStatusCode();
		String statusLine = response.getStatusLine();
		Assert.assertEquals(statusCode, 200);
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");
		System.out.println("OutPut in JSON Format " + responseBody);
		return responseBody;
	}

	public static void valueComparator(String colname, String srcValue, String targetValue, String uniqueValue) {
		if (srcValue.isEmpty()) {

			Assert.assertEquals("", targetValue);
			System.out.println(
					colname + "Validation for Empty fields is successful for record with unique key : " + uniqueValue);

		} else {
			if (srcValue.equalsIgnoreCase(targetValue)) {
				System.out.println(colname + " validation is successful for record with unique key : " + uniqueValue);
			} else {
				System.out
				.println(colname + " validation is not successful for record with unique key : " + uniqueValue);
				Assert.fail();
			}
		}
	}

	@AfterClass()
	public static void softassertTearDown() throws SQLException {

		extent.flush();
	}
	@AfterClass
	public void closeServer() {
		if (server.isRunning() && null != server) {
			System.out.println("Shutdown the Server");
			server.shutdown();
		}
	}
}
