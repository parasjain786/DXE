package com.dxeproject.utils;

import org.testng.Assert;

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.UrlPattern;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class APIWireMock extends BaseClass{
	static String strStubResponse;
	
	public static void initializeServer() {
		System.out.println("Starting WireMock Server");
		server.start();
		WireMock.configureFor(HOST, PORT);

		ResponseDefinitionBuilder mockResponse = new ResponseDefinitionBuilder();
		mockResponse.withStatus(200);
		mockResponse.withStatusMessage("I am Stub");
		mockResponse.withHeader("Content-Type", "text/json");
		mockResponse.withHeader("token", "1234");
		mockResponse.withBodyFile("json/index.json");

		UrlPattern externalUrl = WireMock.urlPathMatching("/api/getNaceDetails");
		WireMock.stubFor(
				WireMock.get(externalUrl)
				.withQueryParam("Order", WireMock.equalTo(prop.getProperty("Orderid")))
				.willReturn(mockResponse));
	}

	public static String wireMockStubReponse() {
		initializeServer();
		String testURI = "http://localhost:" + PORT + "/api/getNaceDetails?Order=" + prop.getProperty("Orderid");
		System.out.println("Service URI: " + testURI);

		Response stubResponse = RestAssured.given().get(testURI)
				.then().statusCode(200).extract().response();
		
		Assert.assertEquals(stubResponse.getStatusCode(), 200);
		Assert.assertEquals(stubResponse.getHeader("token"), "1234");
		
		strStubResponse=stubResponse.getBody().asString();
		System.out.println("Stub Response " + strStubResponse);
		return strStubResponse;
	}
		
}