package com.dxeproject.stepdefintions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;

import com.dxeproject.utils.APIWireMock;
import com.dxeproject.utils.BaseClass;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DXERequirement extends BaseClass {
	static String apiCode;
	static String apiLevel;
	static String apiOrder;
	static String apiParent;
	static String apiRulings;
	static String apiDescription;
	static String apiThisItemExclude;
	static String apiThisItemInclude;
	static String apiThisItemAlsoIncludes;
	static String apiReferenceISIC;
	static String csvOrderId;
	static String csvLevel;
	static String csvCode;
	static String csvParent;
	static String csvDescription;
	static String csvThis_item_includes;
	static String csvThis_item_also_includes;
	static String csvRulings;
	static String csvThis_item_excludes;
	static String csvReference_to_ISIC_Rev_4;
	static String csvPath = User_Dir + "/src/test/resources/sourcedata/NACE_REV2_20220510_110140.csv";
	protected String executionMachine = (prop.getProperty("Machine"));
	String apiResponse;


	static {

		try (InputStream input = new FileInputStream(User_Dir + "/src/test/resources/config/ApiDetails.properties")) {
			prop = new Properties();
			prop.load(input);
		}

		catch (IOException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Given("^I hit API end point for an order id and get success response$")
	public void getAndParseJSONReponse() {

		if (executionMachine.equals("server")) {
			
			apiResponse = getAPISucessRespServer();
		} else {
			
			apiResponse = APIWireMock.wireMockStubReponse();
			
		}

		JSONArray jsonArray = new JSONArray(apiResponse);
		JSONObject jsnobject = jsonArray.getJSONObject(0);

		apiCode = jsnobject.getString("Code");
		apiLevel = jsnobject.getString("Level");
		apiOrder = jsnobject.getString("Order");
		apiParent = jsnobject.getString("Parent");
		apiRulings = jsnobject.getString("Rulings");
		apiDescription = jsnobject.getString("Description");
		apiThisItemExclude = jsnobject.getString("This item excludes");
		apiThisItemInclude = jsnobject.getString("This item includes");
		apiThisItemAlsoIncludes = jsnobject.getString("This item also includes");
		apiReferenceISIC = jsnobject.getString("Reference to ISIC Rev. 4");

	}

	@When("^I validate the data for same order id in CSV$")
	public static void getCSVData() throws IOException, CsvException {

		File csvPathObj = new File(csvPath);
		CSVReader reader = new CSVReader(new FileReader(csvPathObj));
		List<String[]> csvValue = reader.readAll();

		for (int i = 0; i < csvValue.size(); i++) {

			if (csvValue.get(i)[0].equalsIgnoreCase(prop.getProperty("Orderid"))) {// get env from csv

				csvOrderId = csvValue.get(i)[0];
				csvLevel = csvValue.get(i)[1];
				csvCode = csvValue.get(i)[2];
				csvParent = csvValue.get(i)[3];
				csvDescription = csvValue.get(i)[4];
				csvThis_item_includes = csvValue.get(i)[5];
				csvThis_item_also_includes = csvValue.get(i)[6];
				csvRulings = csvValue.get(i)[7];
				csvThis_item_excludes = csvValue.get(i)[8];
				csvReference_to_ISIC_Rev_4 = csvValue.get(i)[9];
			}
		}
		reader.close();
	}

	@Then("Order details should match between CSV and API response")
	public void validateCSVAndAPIResponse() {

		valueComparator("Order Id", apiOrder, csvOrderId, apiOrder);
		valueComparator("Level", apiLevel, csvLevel, apiOrder);
		valueComparator("Code", apiCode, csvCode, apiOrder);
		valueComparator("Parent", apiParent, csvParent, apiOrder);
		valueComparator("Description", apiDescription, csvDescription, apiOrder);
		valueComparator("This Item Includes", apiThisItemInclude, csvThis_item_includes, apiOrder);
		valueComparator("This Item Also Includes", apiThisItemAlsoIncludes, csvThis_item_also_includes, apiOrder);
		valueComparator("Rulings", apiRulings, csvRulings, apiOrder);
		valueComparator("This Item Excludes", apiThisItemExclude, csvThis_item_excludes, apiOrder);
		valueComparator("Ref to ISIC", apiReferenceISIC, csvReference_to_ISIC_Rev_4, apiOrder);

	}
}